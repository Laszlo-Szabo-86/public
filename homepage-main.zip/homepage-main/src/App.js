import { BrowserRouter, Routes, Route } from 'react-router-dom';

import './App.css';

import Layout from './components/Layout';
import Home from './components/Home';

import DocumentHandler from './components/DocumentHandler';
/* -------------------------------------------------------------------------- */

function App() {
  const records = [
    {key: 0, path: "horology/markings-on-soviet-movements"}
  ];

  return (
    <BrowserRouter className="App">
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          {records.map((record) => (
            <Route key={record.key} path={record.path} element={<DocumentHandler path={record.path}/>} />
          ))}
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

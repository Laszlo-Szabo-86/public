import { Outlet } from 'react-router-dom';

import Menu from './Menu';
import Sections from './Sections';

import styles from './styles/frame.module.css'
/* -------------------------------------------------------------------------- */

function Layout() {
  const style = {
    container: {
      display: "flex",
      justifyContent: "space-between"
    },
    main: {
      flex: "0 0 1280px"
    },
    nav: {
      flex: "0 0 300px"
    }
  };

  return (
    <div className="Container" style={style.container}>
      <nav style={style.nav} className={styles.menu}>
        <Menu />
      </nav>
      <main style={style.main}>
        <Outlet />
      </main>
      <nav style={style.nav} className={styles.menu}>
        <Sections />
      </nav>
    </div>
  );
}

export default Layout;
import { Link } from 'react-router-dom';
import {
  ListItem,
  ListIcon,
  ListContent,
  List,
} from 'semantic-ui-react'

import styles from './styles/frame.module.css'
/* -------------------------------------------------------------------------- */

function Menu() {
  return (
    <div>
      <div className={styles.subject}>Horology</div>
      <div className={styles.document}>
        <List>
          <ListItem>
            <ListIcon name='file' />
            <ListContent>
              <Link to="horology/markings-on-soviet-movements">Szovjet óraszerkezetek jelölései</Link>
            </ListContent>
          </ListItem>
        </List>
      </div>
    </div>
  );
}

export default Menu;
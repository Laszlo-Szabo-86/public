function Sections() {
  return (
    <div>
    </div>
  );
}

export default Sections;
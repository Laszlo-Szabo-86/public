import { useState, useEffect } from 'react';

/* -------------------------------------------------------------------------- */
function DocumentHandler({path}) {
  const [article, setArticle] = useState(null);

  useEffect(() => {
    (async () => {
      fetch('/documents/' + path + '.htm')
        .then((response) => response.text())
        .then((text) => {
          setArticle(text)
      });
    })();
  }, [path]);

  /* -------------------------------------------------------------------------- */
  const style = {
    iframe: {
      border: 0,
      width: "1280px",
      height: "99vh"
    }
  };

  return (
    <div>
      <iframe srcDoc={article} style={style.iframe} title="DocumentHandler"></iframe>
    </div>
  );
}

export default DocumentHandler;
